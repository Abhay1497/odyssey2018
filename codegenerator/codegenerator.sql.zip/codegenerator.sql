-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 26, 2018 at 08:27 AM
-- Server version: 5.1.36
-- PHP Version: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `gen`
--

-- --------------------------------------------------------

--
-- Table structure for table `code1`
--

CREATE TABLE IF NOT EXISTS `code1` (
  `id` varchar(200) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `code1`
--

INSERT INTO `code1` (`id`) VALUES
('3'),
('2'),
('1');

-- --------------------------------------------------------

--
-- Table structure for table `codegen`
--

CREATE TABLE IF NOT EXISTS `codegen` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=347 ;

--
-- Dumping data for table `codegen`
--

INSERT INTO `codegen` (`id`) VALUES
(1),
(2),
(3),
(4),
(5),
(6);
